import numpy as np
import soundfile as sf
from scipy.fft import fft, ifft
from Crypto.Cipher import AES
from Crypto.Hash import SHA256
from Crypto.Util.Padding import pad
import getpass

def str_to_bin(s):
    return ''.join(format(ord(c), '08b') for c in s)

def encrypt_message(message, password):
    key = SHA256.new(password.encode()).digest()
    cipher = AES.new(key, AES.MODE_ECB)
    padded = pad(message.encode(), AES.block_size)
    encrypted = cipher.encrypt(padded)
    return encrypted

def embed_message(input_audio, output_audio, message, password):
    data, rate = sf.read(input_audio)
    if data.ndim > 1:
        data = data[:, 0]

    encrypted = encrypt_message(message, password)
    msg_bin = ''.join(format(byte, '08b') for byte in encrypted)
    msg_len = len(msg_bin)
    len_bin = format(msg_len, '016b')
    full_bin = len_bin + msg_bin

    fft_data = fft(data)
    mag = np.abs(fft_data)
    phase = np.angle(fft_data)

    if len(full_bin) + 1 >= len(phase) // 2:
        raise Exception("Thong diep qua dai cho file am thanh")

    for i, bit in enumerate(full_bin):
        phase[i + 1] = np.pi / 2 if bit == '1' else -np.pi / 2
        phase[-(i + 1)] = -phase[i + 1]

    new_fft = mag * np.exp(1j * phase)
    new_data = np.real(ifft(new_fft))
    new_data /= np.max(np.abs(new_data))

    sf.write(output_audio, new_data, rate)
    print("Giau thong diep vao 'stego.wav' thanh cong.")

if __name__ == "__main__":
    with open("text.txt", "r", encoding="utf-8") as f:
        msg = f.read().strip()
    password = getpass.getpass("Tao mat khau cho khoa AES: ")
    embed_message("input.wav", "stego.wav", msg, password)
