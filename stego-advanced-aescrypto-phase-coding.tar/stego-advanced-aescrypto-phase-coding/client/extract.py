import numpy as np
import soundfile as sf
from scipy.fft import fft
from Crypto.Cipher import AES
from Crypto.Hash import SHA256
from Crypto.Util.Padding import unpad
import getpass

def bin_to_bytes(b):
    return bytes(int(b[i:i+8], 2) for i in range(0, len(b), 8))

def decrypt_message(encrypted_bytes, password):
    key = SHA256.new(password.encode()).digest()
    cipher = AES.new(key, AES.MODE_ECB)
    try:
        decrypted = unpad(cipher.decrypt(encrypted_bytes), AES.block_size)
        return decrypted.decode()
    except:
        return None

def extract_message(audio_file, password):
    data, rate = sf.read(audio_file)
    if data.ndim > 1:
        data = data[:, 0]

    fft_data = fft(data)
    phase = np.angle(fft_data)

    len_bin = ''
    for i in range(1, 17):
        len_bin += '1' if phase[i] > 0 else '0'
    msg_len = int(len_bin, 2)

    msg_bin = ''
    for i in range(17, 17 + msg_len):
        msg_bin += '1' if phase[i] > 0 else '0'

    encrypted_bytes = bin_to_bytes(msg_bin)
    message = decrypt_message(encrypted_bytes, password)

    if message:
        print("\nThong diep da duoc giai ma:")
        print("────────────────────────────")
        print(message)
        print("────────────────────────────")
    else:
        print("Khong the giai ma. Mat khau sai hoac du lieu hong.")

if __name__ == "__main__":
    password = getpass.getpass("Nhap mat khau khoa AES: ")
    extract_message("stego.wav", password)
