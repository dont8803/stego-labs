import numpy as np
from scipy.fft import fft, ifft
import soundfile as sf

def str_to_bin(s):
    return ''.join(format(ord(c), '08b') for c in s)

def embed_message(input_audio, output_audio, message):
    data, rate = sf.read(input_audio)
    if data.ndim > 1:
        data = data[:, 0]  # Lay kenh am thanh dau tien (mono)

    msg_bin = str_to_bin(message)
    msg_len = len(msg_bin)
    len_bin = format(len(message), '016b')  # 16 bit do dai (so ky tu)
    full_bin = len_bin + msg_bin

    # In thong tin
    print("Do dai thong diep (so ky tu):", len(message))
    print("Chuoi nhi phan cua do dai (16 bit):", len_bin)
    print("Chuoi nhi phan cua thong diep:", msg_bin)
    print("Chuoi nhi phan se duoc nhung:", full_bin)
    print("Tong so bit se duoc nhung:", len(full_bin))

    # Ghi full_bin ra file de doi chieu khi giai ma
    with open("embed_bits.txt", "w") as f:
        f.write(full_bin)

    fft_data = fft(data)
    mag = np.abs(fft_data)
    phase = np.angle(fft_data)

    if len(full_bin) + 1 >= len(phase) // 2:
        raise Exception("Thong diep qua dai cho file am thanh nay")

    for i, bit in enumerate(full_bin):
        phase[i + 1] = np.pi / 2 if bit == '1' else -np.pi / 2
        phase[-(i + 1)] = -phase[i + 1]  # Doi xung

    new_fft = mag * np.exp(1j * phase)
    new_data = np.real(ifft(new_fft))
    new_data /= np.max(np.abs(new_data))  # Chuan hoa ve [-1, 1]

    sf.write(output_audio, new_data, rate)
    print("Da giau thong diep thanh cong vao file 'stego.wav'")

if __name__ == "__main__":
    with open("text.txt", "r", encoding="utf-8") as f:
        msg = f.read().strip()
    embed_message("input.wav", "stego.wav", msg)
