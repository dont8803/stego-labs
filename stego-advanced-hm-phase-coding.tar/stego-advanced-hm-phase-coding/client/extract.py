import numpy as np
from scipy.fft import fft
import soundfile as sf

def bin_to_str(b):
    chars = [b[i:i+8] for i in range(0, len(b), 8)]
    return ''.join(chr(int(c, 2)) for c in chars)

def extract_message(audio_file):
    data, rate = sf.read(audio_file)
    if data.ndim > 1:
        data = data[:, 0]

    fft_data = fft(data)
    phase = np.angle(fft_data)

    # Doc do dai (16 bit dau)
    len_bin = ''
    for i in range(1, 17):
        len_bin += '1' if phase[i] > 0 else '0'

    msg_len = int(len_bin, 2)
    total_bits = msg_len * 8

    if 17 + total_bits >= len(phase):
        raise ValueError("Thong diep qua dai hoac file am thanh khong du dai de chua thong diep")

    msg_bin = ''
    for i in range(17, 17 + total_bits):
        msg_bin += '1' if phase[i] > 0 else '0'

    message = bin_to_str(msg_bin)

    print("\nThong diep da duoc giai ma:")
    print("-----------------------------")
    print(message)
    print("-----------------------------")

    # Doc lai full_bin da nhung de so sanh
    try:
        with open("embed_bits.txt", "r") as f:
            full_bin = f.read().strip()
    except FileNotFoundError:
        print("Khong tim thay file 'embed_bits.txt' de so sanh bit loi.")
        return

    extracted_bin = len_bin + msg_bin
    compare_len = min(len(full_bin), len(extracted_bin))

    bit_error = sum(1 for i in range(compare_len) if full_bin[i] != extracted_bin[i])
    bit_error_rate = (bit_error / compare_len) * 100 if compare_len > 0 else 0

    print(f"So bit loi: {bit_error}")
    print(f"Ty le bit loi: {bit_error_rate:.2f}%")

if __name__ == "__main__":
    extract_message("stego.wav")
