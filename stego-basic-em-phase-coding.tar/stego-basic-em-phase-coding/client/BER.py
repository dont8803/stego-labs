from getBits import getBits

def BER(hidden, retrieved):
    hidden_bits = getBits(hidden)
    retrieved_bits = getBits(retrieved)

    len_min = min(len(hidden_bits), len(retrieved_bits))
    errors = sum(h != r for h, r in zip(hidden_bits[:len_min], retrieved_bits[:len_min]))

    return 100 * (errors / len_min)
