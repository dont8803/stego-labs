import numpy as np
import soundfile as sf
from scipy.fft import fft, ifft
from getBits import getBits
from BER import BER
from NC import NC
import tkinter as tk
from tkinter import filedialog

def phase_dec(signal, L_msg, L=1024):
    m = 8 * L_msg
    x = signal[:L]  
    Phi = np.angle(fft(x))

    print(f"Chieu dai thong diep nhan duoc (L_msg trong phase_dec): {L_msg}")
    print(f"So luong bit can giai ma (m trong phase_dec): {m}")

    data = ''
    threshold_pos = np.pi / 4
    threshold_neg = -np.pi / 4
    offset = 2 

    for k in range(m):
        index = L//2 - m + k + 1
        index_with_offset = index

        if index_with_offset >= 0 and index_with_offset < len(Phi):
            if Phi[index_with_offset] > threshold_pos:
                data += '0'
            elif Phi[index_with_offset] < threshold_neg:
                data += '1'
            else:
                print(f"Canh bao: Gia tri pha khong ro rang tai index {index_with_offset}: {Phi[index_with_offset]}")
                data += 'x'
        else:
            print(f"Canh bao: Chi so tan so {index_with_offset} nam ngoai pham vi!")
            data += 'x'

    print(f"Chuoi bits giai ma duoc (trong phase_dec): {data}")
    print(f"10 bits dau tien giai ma duoc (trong phase_dec): {data[:10]}")
   
    chars = []
    for i in range(0, len(data), 8):
        byte = data[i:i+8]
        chars.append(chr(int(byte, 2)))

    return ''.join(chars)

# 1.
file_path = input("Nhap duong dan toi file stego (.wav): ").strip()
if not file_path:
	printt("Khong co file duoc nhap")
	exit()
audio_data, fs = sf.read(file_path)

# 2.
text_file = 'text.txt'
with open(text_file, 'r', encoding='utf-8') as f:
    hidden_text = f.read()

# 3.
retrieved_text = phase_dec(audio_data, len(hidden_text))

# 4
err = BER(hidden_text, retrieved_text)
nc  = NC(hidden_text, retrieved_text)

# 
print(f'Text: {retrieved_text}')
print(f'BER : {err:.2f}%')
print(f'NC  : {nc:.4f}')
