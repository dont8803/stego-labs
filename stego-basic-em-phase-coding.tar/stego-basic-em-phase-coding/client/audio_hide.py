import numpy as np
import soundfile as sf
from scipy.fft import fft, ifft
import tkinter as tk
from tkinter import filedialog
import os

def getBits(text):
    matrix = [format(ord(c), '08b') for c in text]
    bin_seq = ''.join(matrix)
    return bin_seq


def phase_enc(signal, text, L=1024):
    plain = signal[:, 0] if signal.ndim > 1 else signal
    data = getBits(text)

    print(f"Do dai chuoi text goc (trong phase_enc): {len(text)}")
    print(f"So luong bit can nhung (m trong phase_enc): {len(data)}")
    print(f"Chuoi bit can nhung (trong phase_enc): {data}") # In oan bo chuoi bit

    I = len(plain)
    m = len(data)
    N = I // L  # số khung (frames)

    s = plain[:N*L].reshape((N, L)).T  # Chia thành các frame L x N (transpose để match MATLAB)

    w = fft(s, axis=0)
    Phi = np.angle(w)
    A = np.abs(w)

    # Phase differences
    DeltaPhi = np.zeros((L, N))
    for k in range(1, N):
        DeltaPhi[:, k] = Phi[:, k] - Phi[:, k-1]

    # Mã hóa dữ liệu vào pha
    PhiData = np.zeros(m)
    for k in range(m):
        if data[k] == '0':
            PhiData[k] = np.pi/2
        else:
            PhiData[k] = -np.pi/2

    # Chèn PhiData vào pha mới (CHỈ NHÚNG VÀO DẢI ĐẦU)
    # Chèn PhiData vào pha mới (MỞ RỘNG VÙNG NHÚNG)
    Phi_new = np.zeros_like(Phi)
    Phi_new[:, 0] = Phi[:, 0]
    mid = L // 2
    offset = 2 # Thử mở rộng thêm 2 bins ở mỗi bên
    Phi_new[mid - m + 1 - offset : mid + 1 + offset, 0] = np.pad(PhiData, (offset, offset), 'constant')

    # Khôi phục pha toàn bộ từ phase difference
    for k in range(1, N):
        Phi_new[:, k] = Phi_new[:, k-1] + DeltaPhi[:, k]

    # Inverse FFT để lấy tín hiệu mới
    z = np.real(ifft(A * np.exp(1j * Phi_new), axis=0))
    snew = z.T.reshape(N * L)

    # Ghép phần còn lại
    out = np.concatenate((snew, plain[N*L:I]))

    return out

# ======= Main script ========

# Chọn file âm thanh
file_path = input("Nhap duong dan file WAV can nhung: ").strip()
if not os.path.isfile(file_path):
    print("Khong tim thay file. Thoat chuong trinh")
    exit()

audio_data, audio_fs = sf.read(file_path)
audio_name = os.path.splitext(os.path.basename(file_path))[0]
audio_dir = os.path.dirname(file_path)

# Đọc file text
text_file = "text.txt"
with open(text_file, "r", encoding="utf-8") as f:
    text = f.read()

print(f"Do dai chuoi text doc tu file (main script - hide): {len(text)}") # Thêm dòng này

# Mã hóa pha
out = phase_enc(audio_data, text)

# Lưu file stego
stego_filename = os.path.join(audio_dir, audio_name + "_stego.wav")
sf.write(stego_filename, out, audio_fs)

print(f"Giau Thanh Cong, file am thanh moi duoc luu voi ten {stego_filename}")
