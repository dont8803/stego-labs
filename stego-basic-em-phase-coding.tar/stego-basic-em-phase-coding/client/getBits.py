def getBits(text):
    matrix = [format(ord(c), '08b') for c in text]
    bin_seq = ''.join(matrix)
    return bin_seq
