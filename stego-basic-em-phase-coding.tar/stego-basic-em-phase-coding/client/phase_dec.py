import numpy as np
from scipy.fft import fft, ifft
def phase_dec(signal, L_msg, L=1024):
    m = 8 * L_msg
    x = signal[:L]  # lấy đoạn đầu
    Phi = np.angle(fft(x))
    
    data = ''
    for k in range(m):
        if Phi[L//2 - m + k] > 0:
            data += '0'
        else:
            data += '1'

    # Gom mỗi 8 bit thành 1 ký tự
    chars = []
    for i in range(0, len(data), 8):
        byte = data[i:i+8]
        chars.append(chr(int(byte, 2)))

    return ''.join(chars)
