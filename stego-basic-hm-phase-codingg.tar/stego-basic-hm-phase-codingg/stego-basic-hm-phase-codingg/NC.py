import numpy as np
from getBits import getBits
def NC(hidden, retrieved):
    hidden_bits = getBits(hidden)
    retrieved_bits = getBits(retrieved)

    xbit = np.array([int(b) for b in hidden_bits], dtype=np.float32)
    ybit = np.array([int(b) for b in retrieved_bits], dtype=np.float32)

    len_min = min(len(xbit), len(ybit))
    xbit = xbit[:len_min]
    ybit = ybit[:len_min]

    s1 = np.sum(xbit * ybit)
    s2 = np.sqrt(np.sum(xbit**2) * np.sum(ybit**2))

    return s1 / s2
