import numpy as np
import soundfile as sf
from scipy.fft import fft, ifft
from getBits import getBits
from BER import BER
from NC import NC
import tkinter as tk
from tkinter import filedialog

def phase_dec(signal, L_msg, L=1024):
    m = 8 * L_msg
    x = signal[:L]  # lấy đoạn đầu
    Phi = np.angle(fft(x))

    print(f"Chiều dài thông điệp nhận được (L_msg trong phase_dec): {L_msg}")
    print(f"Số lượng bits cần giải mã (m trong phase_dec): {m}")

    data = ''
    threshold_pos = np.pi / 4
    threshold_neg = -np.pi / 4
    offset = 2 # Phải khớp với offset ở audio_hide.py

    for k in range(m):
        index = L//2 - m + k + 1 # Vẫn đọc từ vùng chính
        index_with_offset = index # Không cần offset khi đọc, chúng ta đọc đúng m bit

        if index_with_offset >= 0 and index_with_offset < len(Phi):
            if Phi[index_with_offset] > threshold_pos:
                data += '0'
            elif Phi[index_with_offset] < threshold_neg:
                data += '1'
            else:
                print(f"Cảnh báo: Giá trị pha không rõ ràng tại index {index_with_offset}: {Phi[index_with_offset]}")
                data += 'x'
        else:
            print(f"Cảnh báo: Chỉ số tần số {index_with_offset} nằm ngoài phạm vi!")
            data += 'x'

    print(f"Chuỗi bits giải mã được (trong phase_dec): {data}")
    print(f"10 bits đầu tiên giải mã được (trong phase_dec): {data[:10]}")

    # Gom mỗi 8 bit thành 1 ký tự
    chars = []
    for i in range(0, len(data), 8):
        byte = data[i:i+8]
        chars.append(chr(int(byte, 2)))

    return ''.join(chars)

# 1. Đọc file audio
root = tk.Tk()
root.withdraw()  # Ẩn cửa sổ chính
file_path = filedialog.askopenfilename(filetypes=[("WAV files", "*.wav")], title="Chọn file stego (.wav)")
if not file_path:
    print("No file selected.")
    exit()
audio_data, fs = sf.read(file_path)

# 2. Đọc file text gốc
text_file = 'text.txt'
with open(text_file, 'r', encoding='utf-8') as f:
    hidden_text = f.read()

# 3. Giải mã
retrieved_text = phase_dec(audio_data, len(hidden_text))

# 4. Tính BER và NC
err = BER(hidden_text, retrieved_text)
nc  = NC(hidden_text, retrieved_text)

# 5. Hiển thị kết quả
print(f'Text: {retrieved_text}')
print(f'BER : {err:.2f}%')
print(f'NC  : {nc:.4f}')